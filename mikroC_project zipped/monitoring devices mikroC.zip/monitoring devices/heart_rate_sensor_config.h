#ifndef HEARTRATE_CONFIG_H
#define HEARTRATE_CONFIG_H

u8* HEARTRATE_Bpm(u8 digital_heartRate);


#endif